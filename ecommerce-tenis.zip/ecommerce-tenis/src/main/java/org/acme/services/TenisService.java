package org.acme.services;

import java.util.List;

import org.acme.dto.TenisDTO;
import org.acme.model.Tenis;
import org.acme.repository.TenisRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@ApplicationScoped
public class TenisService {

    @Inject
    private TenisRepository tenisRepository;

    @Transactional
    public Tenis create(@Valid TenisDTO dto) {
        Tenis tenis = new Tenis();
        tenisRepository.persist(tenis);
        return tenis;
    }

    @Transactional
    public void update(Long id, @Valid TenisDTO dto) {
        Tenis tenis = tenisRepository.findById(id);
        if (tenis != null) {
        }
    }

    @Transactional
    public void delete(Long id) {
        Tenis tenis = tenisRepository.findById(id);
        if (tenis != null) {
            tenisRepository.delete(tenis);
        }
    }

    public Tenis findById(Long id) {
        return tenisRepository.findById(id);
    }

    public List<Tenis> findAll() {
        return tenisRepository.listAll();
    }
}
