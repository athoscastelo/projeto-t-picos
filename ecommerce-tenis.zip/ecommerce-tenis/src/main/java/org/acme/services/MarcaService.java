package org.acme.services;

import java.util.List;

import org.acme.dto.MarcaDTO;
import org.acme.model.Marca;
import org.acme.repository.MarcaRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@ApplicationScoped
public class MarcaService {

    @Inject
    private MarcaRepository marcaRepository;

    @Transactional
    public Marca create(@Valid MarcaDTO dto) {
        Marca marca = new Marca();
        marca.setNome(dto.nome());
        marcaRepository.persist(marca);
        return marca;
    }

    @Transactional
    public void update(Long id, @Valid MarcaDTO dto) {
        Marca marca = marcaRepository.findById(id);
        if (marca != null) {
            marca.setNome(dto.nome());
        }
    }

    @Transactional
    public void delete(Long id) {
        Marca marca = marcaRepository.findById(id);
        if (marca != null) {
            marcaRepository.delete(marca);
        }
    }

    public Marca findById(Long id) {
        return marcaRepository.findById(id);
    }

    public List<Marca> findAll() {
        return marcaRepository.listAll();
    }
}