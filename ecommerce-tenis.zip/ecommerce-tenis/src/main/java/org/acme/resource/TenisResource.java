package org.acme.resource;


import java.util.List;

import org.acme.dto.TenisResponseDTO;
import org.acme.dto.TenisDTO;
import org.acme.model.Tenis;
import org.acme.services.TenisService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/tenis")
public class TenisResource {

    @Inject
    private TenisService tenisService;

    @GET
    @Path("/{id}")
    public TenisResponseDTO findById(@PathParam("id") Long id) {
        return TenisResponseDTO.valueOf(tenisService.findById(id));
    }

    @GET
    public List<TenisResponseDTO> findAll() {
        return tenisService.findAll().stream()
                .map(e -> TenisResponseDTO.valueOf(e))
                .toList();
    }

    @POST
    @Transactional
    public TenisResponseDTO create(@Valid TenisDTO dto) {
        Tenis tenis = tenisService.create(dto);
        return TenisResponseDTO.valueOf(tenis);
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public void update(@PathParam("id") Long id, @Valid TenisDTO dto) {
        tenisService.update(id, dto);
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public void delete(@PathParam("id") Long id) {
        tenisService.delete(id);
    }
}
