package org.acme.dto;

import org.acme.model.Tenis;

public record TenisResponseDTO(
    Long id,
    String nome
) {
    public static TenisResponseDTO valueOf(Tenis tenis) {
        return new TenisResponseDTO(
            tenis.getId(),
            tenis.getNome() 
        );
    }
}




