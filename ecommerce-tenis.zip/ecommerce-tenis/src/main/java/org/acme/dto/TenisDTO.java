package org.acme.dto;

public record TenisDTO(String nome, String descricao, Double preco, Long marcaId) {}