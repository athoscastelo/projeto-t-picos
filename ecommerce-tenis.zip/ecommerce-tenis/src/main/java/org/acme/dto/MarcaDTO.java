package org.acme.dto;

public record MarcaDTO(String nome) {}
